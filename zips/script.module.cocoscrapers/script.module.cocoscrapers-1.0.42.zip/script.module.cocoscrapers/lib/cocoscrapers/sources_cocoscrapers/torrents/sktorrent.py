# -*- coding: utf-8 -*-
"""Authenticated SkTorrent.eu provider for CocoScrapers."""

import re
import unicodedata
from html import unescape
from time import time
from urllib.parse import quote_plus

from cocoscrapers.modules import client, control, log_utils, source_utils


class source:
	priority = 2
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://sktorrent.eu/torrent'
		self.search_link = '/torrents_v2.php?search=%s&active=0'
		self.login_link = '/login.php'
		self.item_totals = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'CAM': 0}
		self.min_seeders = 0
		self._cookie = None
		self._login_attempted = False

	@staticmethod
	def _plain(value):
		value = unescape(re.sub(r'<[^>]+>', ' ', value or ''))
		value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
		return re.sub(r'[^a-z0-9]+', ' ', value.lower()).strip()

	def _titles(self, title, aliases):
		values = [title]
		for alias in aliases or []:
			if isinstance(alias, dict):
				alias = alias.get('title')
			if alias:
				values.append(alias)
		return [self._plain(value) for value in values if self._plain(value)]

	def _title_matches(self, release, title, aliases, marker):
		release_plain = self._plain(release)
		marker_plain = self._plain(str(marker))
		if marker_plain and not re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(marker_plain), release_plain):
			return False
		prefix = release_plain.split(marker_plain, 1)[0] if marker_plain else release_plain
		return any(re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(candidate), prefix)
			for candidate in self._titles(title, aliases))

	def _authenticate(self):
		if self._login_attempted:
			return self._cookie
		self._login_attempted = True
		username = control.setting('sktorrent.username').strip()
		password = control.setting('sktorrent.password')
		if not username or not password:
			log_utils.log('SKTORRENT: username and password are required')
			return None
		self._cookie = client.request(
			self.base_link + self.login_link,
			post={'uid': username, 'pwd': password},
			output='cookie', timeout=10)
		if not self._cookie:
			log_utils.log('SKTORRENT: login failed')
		return self._cookie

	def _search(self, query):
		cookie = self._authenticate()
		if not cookie:
			return []
		url = self.base_link + (self.search_link % quote_plus(query))
		html = client.request(url, cookie=cookie, timeout=10)
		if not html:
			return []
		pattern = re.compile(
			r'<a\s+href=["\']?details\.php\?[^>]*?&(?:amp;)?id=([0-9a-f]{40})["\']?[^>]*>.*?<br\s*/?>(.*?)</a>'
			r'\s*<br\s*/?>\s*Velkost\s+([^|<]+).*?Odosielaju\s*:\s*([0-9,]+)',
			re.I | re.S)
		results = []
		seen = set()
		for info_hash, name, size, seeders in pattern.findall(html):
			if info_hash in seen:
				continue
			seen.add(info_hash)
			name = unescape(re.sub(r'<[^>]+>', '', name)).strip()
			results.append((info_hash.lower(), name, size.strip(), int(seeders.replace(',', ''))))
		return results

	def _add(self, info_hash, name, size, seeders, package=None, last_season=None):
		if seeders < self.min_seeders:
			return
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, quote_plus(name))
		name_info = source_utils.info_from_name(
			name, self.title, self.year, self.hdlr if not package else None,
			self.episode_title, season=getattr(self, 'season_x', None), pack=package)
		if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables):
			return
		quality, info = source_utils.get_release_quality(name_info, url)
		try:
			dsize, isize = source_utils._size(size)
			info.insert(0, isize)
		except Exception:
			dsize = 0
		item = {'provider': 'sktorrent', 'source': 'torrent', 'seeders': seeders,
			'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
			'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False,
			'debridonly': True, 'size': dsize}
		if package:
			item['package'] = package
		if last_season:
			item['last_season'] = last_season
		self.sources.append(item)
		self.item_totals[quality] += 1

	def sources(self, data, hostDict):
		self.sources = []
		if not data:
			return self.sources
		start = time()
		try:
			self.aliases = data.get('aliases', [])
			self.year = str(data.get('year', ''))
			self.episode_title = None
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle']
				self.episode_title = data.get('title')
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
			else:
				self.title = data['title']
				self.hdlr = self.year
			self.undesirables = source_utils.get_undesirables()
			for row in self._search('%s %s' % (self.title, self.hdlr)):
				if self._title_matches(row[1], self.title, self.aliases, self.hdlr):
					self._add(*row)
		except Exception:
			source_utils.scraper_error('SKTORRENT')
		log_utils.log('#STATS - SKTORRENT found %d results in %.2f seconds' % (len(self.sources), time() - start))
		return self.sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.sources = []
		if not data:
			return self.sources
		start = time()
		try:
			self.title = data['tvshowtitle']
			self.aliases = data.get('aliases', [])
			self.year = str(data.get('year', ''))
			self.episode_title = None
			self.hdlr = None
			self.season_x = str(data['season'])
			self.undesirables = source_utils.get_undesirables()
			if search_series:
				queries = ('%s komplet' % self.title, '%s S01' % self.title)
			else:
				queries = ('%s S%s' % (self.title, self.season_x.zfill(2)), '%s seria %s' % (self.title, self.season_x))
			seen = set()
			for query in queries:
				for row in self._search(query):
					if row[0] in seen or not self._title_matches(row[1], self.title, self.aliases, ''):
						continue
					plain = self._plain(row[1])
					if search_series:
						match = re.search(r'(?:s|season|seria)\s*0?1(?:\s+to\s+|\s+az\s+|\s+)(?:s|season|seria)?\s*0?([0-9]{1,2})', plain)
						if not match and not any(word in plain for word in ('complete', 'komplet', 'vsetky serie')):
							continue
						last_season = int(match.group(1)) if match else int(total_seasons or self.season_x)
						self._add(*row, package='show', last_season=last_season)
					else:
						season = int(self.season_x)
						if re.search(r's\s*0?%d\s*e\s*[0-9]+' % season, plain):
							continue
						if not re.search(r'(?:s|season|seria)\s*0?%d(?:\s|$)' % season, plain):
							continue
						self._add(*row, package='season')
					seen.add(row[0])
		except Exception:
			source_utils.scraper_error('SKTORRENT')
		log_utils.log('#STATS - SKTORRENT(pack) found %d results in %.2f seconds' % (len(self.sources), time() - start))
		return self.sources
