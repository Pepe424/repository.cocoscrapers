# -*- coding: utf-8 -*-
"""Authenticated TreZzoR (tracker.czech-server.com) provider."""

import hashlib
import re
import unicodedata
from html import unescape
from time import time
from urllib.parse import quote_plus, urljoin, urlparse

from cocoscrapers.modules import client, control, log_utils, source_utils


class source:
	priority = 2
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://tracker.czech-server.com'
		self.login_link = '/prihlasenie.php'
		self.search_link = '/torrents.php?search=%s&active=0'
		self.item_totals = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'CAM': 0}
		self.min_seeders = 0
		self._cookie = None
		self._login_attempted = False

	@staticmethod
	def _plain(value):
		value = unescape(re.sub(r'<[^>]+>', ' ', value or ''))
		value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
		return re.sub(r'[^a-z0-9]+', ' ', value.lower()).strip()

	@staticmethod
	def _decode(value):
		if isinstance(value, bytes):
			return value.decode('windows-1250', errors='ignore')
		return value or ''

	def _titles(self, title, aliases):
		values = [title]
		for alias in aliases or []:
			if isinstance(alias, dict):
				alias = alias.get('title')
			if alias:
				values.append(alias)
		return [self._plain(value) for value in values if self._plain(value)]

	def _title_matches(self, release, title, aliases, marker):
		release_plain = self._plain(release)
		marker_plain = self._plain(str(marker))
		if marker_plain and not re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(marker_plain), release_plain):
			return False
		prefix = release_plain.split(marker_plain, 1)[0] if marker_plain else release_plain
		return any(re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(candidate), prefix)
			for candidate in self._titles(title, aliases))

	def _authenticate(self):
		if self._login_attempted:
			return self._cookie
		self._login_attempted = True
		username = control.setting('trezzor.username').strip()
		password = control.setting('trezzor.password')
		if not username or not password:
			log_utils.log('TREZZOR: username and password are required')
			return None
		self._cookie = client.request(
			self.base_link + self.login_link,
			post={'uid': username, 'pwd': password, 'windows-1250': ''},
			output='cookie', timeout=10)
		if not self._cookie:
			log_utils.log('TREZZOR: login failed')
		return self._cookie

	@staticmethod
	def _skip_bencode(data, position):
		token = data[position:position + 1]
		if token == b'i':
			return data.index(b'e', position + 1) + 1
		if token in (b'l', b'd'):
			position += 1
			while data[position:position + 1] != b'e':
				position = source._skip_bencode(data, position)
			return position + 1
		colon = data.index(b':', position)
		length = int(data[position:colon])
		return colon + 1 + length

	@staticmethod
	def _torrent_info_hash(data):
		try:
			if not data or data[:1] != b'd':
				return None
			position = 1
			while data[position:position + 1] != b'e':
				colon = data.index(b':', position)
				length = int(data[position:colon])
				key_start = colon + 1
				key_end = key_start + length
				key = data[key_start:key_end]
				value_start = key_end
				value_end = source._skip_bencode(data, value_start)
				if key == b'info':
					return hashlib.sha1(data[value_start:value_end]).hexdigest()
				position = value_end
		except Exception:
			return None
		return None

	@staticmethod
	def _torrent_announce(data):
		try:
			match = re.search(br'8:announce(\d+):', data or b'')
			if not match:
				return None
			start = match.end()
			announce = data[start:start + int(match.group(1))].decode('utf-8', errors='ignore')
			parsed = urlparse(announce)
			if parsed.scheme not in ('http', 'https') or not parsed.hostname:
				return None
			if not parsed.hostname.endswith('czech-server.com'):
				return None
			return announce
		except Exception:
			return None

	@staticmethod
	def _clean_anchor(value):
		value = unescape(re.sub(r'<[^>]+>', '', value or ''))
		value = re.sub(r'[\r\n\t]+', '', value)
		return re.sub(r' {2,}', ' ', value).strip()

	def _parse_rows(self, html):
		results = []
		seen = set()
		for row in client.parseDOM(html, 'tr'):
			row = unescape(row)
			details = re.search(
				r'href\s*=\s*["\']([^"\']*details\.php\?[^"\']*\bslug=([^"\'&]+)[^"\']*)["\']',
				row, re.I)
			if not details:
				continue
			torrent_slug = details.group(2)
			if torrent_slug in seen:
				continue
			anchor = re.search(
				r'<a\b(?P<attrs>[^>]*details\.php\?[^>]*?\bslug=%s[^>]*)>(?P<body>.*?)</a>'
				% re.escape(torrent_slug), row, re.I | re.S)
			name = ''
			if anchor:
				name_attr = re.search(r'title=["\'](?:Detaily:\s*)?([^"\']+)', anchor.group('attrs'), re.I)
				name = unescape(name_attr.group(1)).strip() if name_attr else self._clean_anchor(anchor.group('body'))
			if not name:
				continue
			download = re.search(
				r'href\s*=\s*["\']([^"\']*download\.php\?[^"\']*\bslug=%s[^"\']*)["\']'
				% re.escape(torrent_slug), row, re.I)
			download_link = download.group(1) if download else None
			size_match = re.search(
				r'<td\b(?=[^>]*class=["\'][^"\']*\blista\b)[^>]*>\s*'
				r'(\d+(?:[.,]\d+)?\s*(?:KB|MB|GB|TB|KiB|MiB|GiB|TiB))\s*</td>',
				row, re.I | re.S)
			size = size_match.group(1).replace(',', '.') if size_match else ''
			seed_match = re.search(r'class=["\'][^"\']*\bgreen\b[^"\']*["\'][^>]*>\s*(?:<a[^>]*>)?\s*(\d+)', row, re.I)
			if not seed_match:
				seed_match = re.search(r'(?:peerlist|peers)\.php[^>]*>\s*(?:<[^>]+>)*\s*(\d+)', row, re.I)
			seeders = int(seed_match.group(1)) if seed_match else 0
			seen.add(torrent_slug)
			results.append((torrent_slug, download_link, name, size, seeders))
		return results

	def _download_torrent(self, torrent_slug, download_link):
		if not download_link:
			details = client.request(
				'%s/details.php?slug=%s' % (self.base_link, torrent_slug),
				cookie=self._cookie, timeout=10, as_bytes=True)
			details = self._decode(details)
			match = re.search(
				r'href\s*=\s*["\']([^"\']*download\.php\?[^"\']*\bslug=%s[^"\']*)["\']'
				% re.escape(torrent_slug), unescape(details), re.I)
			download_link = match.group(1) if match else None
		if not download_link:
			return None
		return client.request(urljoin(self.base_link + '/', download_link),
			cookie=self._cookie, timeout=10, as_bytes=True)

	def _search(self, query):
		cookie = self._authenticate()
		if not cookie:
			return []
		raw = client.request(self.base_link + (self.search_link % quote_plus(query)),
			cookie=cookie, timeout=10, as_bytes=True)
		html = self._decode(raw)
		login_form = re.search(r'<form[^>]+(?:action=["\']?prihlasenie\.php|name=["\']?login)', html, re.I)
		if not html or 'ERRORNOT_AUTHORIZED' in html or login_form:
			log_utils.log('TREZZOR: search rejected; check username and password')
			return []
		return self._parse_rows(html)

	def _add(self, torrent_slug, download_link, name, size, seeders, package=None, last_season=None):
		if seeders < self.min_seeders:
			return
		torrent_data = self._download_torrent(torrent_slug, download_link)
		info_hash = self._torrent_info_hash(torrent_data)
		if not info_hash:
			return
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, quote_plus(name))
		announce = self._torrent_announce(torrent_data)
		if announce:
			url += '&tr=%s' % quote_plus(announce)
		name_info = source_utils.info_from_name(
			name, self.title, self.year, self.hdlr if not package else None,
			self.episode_title, season=getattr(self, 'season_x', None), pack=package)
		if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables):
			return
		quality, info = source_utils.get_release_quality(name_info, url)
		try:
			dsize, isize = source_utils._size(size)
			if isize:
				info.insert(0, isize)
		except Exception:
			dsize = 0
		item = {'provider': 'trezzor', 'source': 'torrent', 'seeders': seeders,
			'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
			'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False,
			'debridonly': True, 'size': dsize}
		if package:
			item['package'] = package
		if last_season:
			item['last_season'] = last_season
		self.sources.append(item)
		self.item_totals[quality] += 1

	def _queries(self, suffix):
		queries = []
		for title in [self.title] + [item.get('title') if isinstance(item, dict) else item for item in self.aliases or []]:
			query = '%s %s' % (title, suffix) if title else ''
			if query and self._plain(query) not in [self._plain(item) for item in queries]:
				queries.append(query)
			if len(queries) == 3:
				break
		return queries

	def sources(self, data, hostDict):
		self.sources = []
		if not data:
			return self.sources
		start = time()
		try:
			self.aliases = data.get('aliases', [])
			self.year = str(data.get('year', ''))
			self.episode_title = None
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle']
				self.episode_title = data.get('title')
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
			else:
				self.title = data['title']
				self.hdlr = self.year
			self.undesirables = source_utils.get_undesirables()
			seen = set()
			for query in self._queries(self.hdlr):
				for row in self._search(query):
					if row[0] in seen or not self._title_matches(row[2], self.title, self.aliases, self.hdlr):
						continue
					seen.add(row[0])
					self._add(*row)
		except Exception:
			source_utils.scraper_error('TREZZOR')
		log_utils.log('#STATS - TREZZOR found %d results in %.2f seconds' % (len(self.sources), time() - start))
		return self.sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.sources = []
		if not data:
			return self.sources
		start = time()
		try:
			self.title = data['tvshowtitle']
			self.aliases = data.get('aliases', [])
			self.year = str(data.get('year', ''))
			self.episode_title = None
			self.hdlr = None
			self.season_x = str(data['season'])
			self.undesirables = source_utils.get_undesirables()
			suffixes = ('komplet', 'S01') if search_series else ('S%s' % self.season_x.zfill(2), 'seria %s' % self.season_x)
			seen = set()
			for suffix in suffixes:
				for query in self._queries(suffix):
					for row in self._search(query):
						if row[0] in seen or not self._title_matches(row[2], self.title, self.aliases, ''):
							continue
						plain = self._plain(row[2])
						if search_series:
							match = re.search(r'(?:s|season|seria)\s*0?1(?:\s+to\s+|\s+az\s+|\s+)(?:s|season|seria)?\s*0?([0-9]{1,2})', plain)
							if not match and not any(word in plain for word in ('complete', 'komplet', 'vsetky serie')):
								continue
							last_season = int(match.group(1)) if match else int(total_seasons or self.season_x)
							self._add(*row, package='show', last_season=last_season)
						else:
							season = int(self.season_x)
							if re.search(r's\s*0?%d\s*e\s*[0-9]+' % season, plain):
								continue
							if not re.search(r'(?:s|season|seria)\s*0?%d(?:\s|$)' % season, plain):
								continue
							self._add(*row, package='season')
						seen.add(row[0])
		except Exception:
			source_utils.scraper_error('TREZZOR')
		log_utils.log('#STATS - TREZZOR(pack) found %d results in %.2f seconds' % (len(self.sources), time() - start))
		return self.sources
